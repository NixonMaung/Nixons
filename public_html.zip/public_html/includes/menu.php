        <nav>
            <ul>
			<form>
                <li><a href="index.php" style="color:white">Home</a></li>
                <li><a href="accommodation.php" style="color:white">Post an ad</a></li>
                <li><a href="index.php" style="color:white">Forum</a></li>
				<li><a href="indax.php" style="color:white" >Search</a></li>
				<li><a href="contact.php" style="color:white">Contact us</a></li>	
				</form>
            </ul>
        </nav>