  <header>
        <h1 class="logo">Comp1687</h1>
		
		<body style="background-color:#212F3D">
		 
		
<?php  include 'includes/menu.php';?>
		
        <div class="clear"></div>
    </header>