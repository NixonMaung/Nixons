 <footer>
        Comp1687 (2016/17), Web Application Development. CRN 253434.Created by MA, University of Greenwich final year coursework.
    </footer>