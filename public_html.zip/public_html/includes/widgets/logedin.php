 <div class="widget">
                <h2>Hello, <?php echo $user_data['first_name'];?>!</h2>
                <div class="inner">
                  <ul>
				 
				   <li>
				    <a href="accommodation.php">New Ad</a>
				   </li>
				    <li>
				    <a href="userPost.php">Your post</a>
				    </li>
				    <li>
				    <a href="changepassword.php">Change password</a>
				   </li>
				    <li>
				  <a href="index.php">Profile</a>
				  </li>
				  
				     <li>
				    <a href="settings.php">Settings</a>
				   </li>
				  <li>
				  <a href="logout.php">Log out</a>
				  </li>
				  
				  
				   
				   
				  
				  </ul>
                </div>
            </div>
           