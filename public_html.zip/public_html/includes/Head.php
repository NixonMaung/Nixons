<head>
    <title>Comp1687</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/screen.css">
</head>