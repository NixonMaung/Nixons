<?php 
$con = mysqli_connect('localhost', 'ma9892p', 'ma9892p' , 'ma9892p');
?>